// Hyper Ceramide - Lightweight Theme JS
document.addEventListener('DOMContentLoaded', function() {
  // Mobile menu
  const menuBtn = document.querySelector('.mobile-menu-btn');
  const mobileMenu = document.querySelector('.mobile-menu');
  const overlay = document.querySelector('.mobile-menu__overlay');
  const closeBtn = document.querySelector('.mobile-menu__close-btn');
  
  function toggleMenu() {
    if (!mobileMenu || !overlay) return;
    const isOpen = mobileMenu.classList.toggle('open');
    overlay.classList.toggle('open');
    document.body.style.overflow = isOpen ? 'hidden' : '';
  }
  
  if (menuBtn) menuBtn.addEventListener('click', toggleMenu);
  if (overlay) overlay.addEventListener('click', toggleMenu);
  if (closeBtn) closeBtn.addEventListener('click', toggleMenu);

  // Quantity selectors
  document.querySelectorAll('.qty-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var input = this.parentElement.querySelector('.qty-input');
      if (!input) return;
      var step = parseInt(input.getAttribute('step') || '1');
      var min = parseInt(input.getAttribute('min') || '1');
      var max = parseInt(input.getAttribute('max') || '9999');
      var val = parseInt(input.value) || min;
      if (this.classList.contains('qty-plus')) val = Math.min(val + step, max);
      if (this.classList.contains('qty-minus')) val = Math.max(val - step, min);
      input.value = val;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });

  // Header scroll effect
  var header = document.querySelector('.header');
  if (header && header.hasAttribute('data-sticky')) {
    window.addEventListener('scroll', function() {
      header.classList.toggle('header--scrolled', window.scrollY > 50);
    });
  }

  // Product thumbnails
  document.querySelectorAll('.product__thumb').forEach(function(thumb) {
    thumb.addEventListener('click', function() {
      var main = document.querySelector('.product__main-image');
      if (main) main.src = this.src.replace(/_[0-9]+x[0-9]+/, '');
      document.querySelectorAll('.product__thumb').forEach(function(t) { t.classList.remove('active'); });
      this.classList.add('active');
    });
  });
});
